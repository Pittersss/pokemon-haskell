# Revision history for pokemon-game

## 0.0 -- YYYY-mm-dd

* First version. Released on an unsuspecting world.
