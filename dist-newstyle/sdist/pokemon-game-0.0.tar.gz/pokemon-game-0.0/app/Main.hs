
module Main where
import Fudget

main :: IO ()
main = putStrLn "Hello, Haskell!"
